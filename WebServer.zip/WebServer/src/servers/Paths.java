package servers;

public class Paths {
	static String networks = "/home/deependra/networks/";
	static String slashHomeslash = "/home/";
}
